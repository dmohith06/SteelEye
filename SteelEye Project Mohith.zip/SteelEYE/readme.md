
Run:
run from main.py 

Requirements:
pip install pandas
pip install requests