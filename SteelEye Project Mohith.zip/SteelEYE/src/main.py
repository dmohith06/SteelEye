import pandas as pd
import time
from modules import *
from logger import logger
log = logger().getLogger(__name__)

def read_customer_data(laureate_url):
    """
    :param laureate_url: to read json from api [laureates]
    :return: read url data and converts it dataframe
    """
    customer_data = pd.DataFrame(get_response(laureate_url).json()['laureates'])
    return customer_data

def read_countries_codes_data(countries_url):
    """
    :param countries_url: to read json from api [countries]
    :return: read url data and converts it dataframe
    """
    countries_codes = pd.DataFrame(get_response(countries_url).json()['countries']).fillna(
        '<no-code>')
    return countries_codes

def extract_required_details(customer_data, countries_codes):
    """
    :param customer_data: customer data dataframe
    :param countries_codes: country and their respective codes dataframe
    :return: create an empty dataframe , maps data from given two dataframes,does transformation and gives
            dataframe with id, name, born, unique_prize_years, unique_prize_categories, gender,
            bornCountryCode columns
    """
    #read name and code as one dictionary
    countries_codes = countries_codes.set_index('name')['code'].to_dict()

    required_details = pd.DataFrame()
    required_details['id'] = customer_data['id']
    log.info("required_details id Column data is assigned by customer_data id")
    required_details['name'] = customer_data['firstname'] + ' ' + customer_data['surname'].fillna('')
    log.info("required_details name Column data is assigned by customer_data firstname, surname")
    required_details['born'] = customer_data['born']
    log.info("required_details born Column data is assigned by customer_data born")
    required_details['unique_prize_years'] = customer_data['prizes'].apply(lambda x: extract_unique_prize_years(x))
    log.info("extracted unique prize years data")
    required_details['unique_prize_categories'] = customer_data['prizes'].apply(
        lambda x: extract_unique_prize_categories(x))
    log.info("extracted unique prize years categories")
    required_details['gender'] = customer_data['gender']
    log.info("required_details gender Column data is assigned by customer_data gender")
    for country, code in countries_codes.items():
        if code == '<no-code>':
            code = ''.join([c for c in country if c.isupper()])
            countries_codes[country] = code
    log.info("Codes with is assigned with upper letters of country")
    required_details['bornCountryCode'] = customer_data['bornCountryCode'].apply(
        lambda x: mapping_countries_codes(countries_codes, x))
    log.info("bornCountryCode is mapped for countries")
    return required_details

def main():
    """
    :return: creates csv in results folder
    """
    log.info("***********Process Started***********")

    laureate_url = 'https://api.nobelprize.org/v1/laureate.json'
    customer_data = read_customer_data(laureate_url)
    log.info(laureate_url + " " + " data convert to dataframe")

    countries_url = 'https://api.nobelprize.org/v1/country.json'
    countries_codes = read_countries_codes_data(countries_url)
    log.info(countries_url + " " + " data convert to dataframe")

    required_details = extract_required_details(customer_data, countries_codes)

    required_details.to_csv("../results/required_details.csv", index=False)
    log.info("Required details generated as csv")

if __name__=="__main__":
    """
    Whole program can be run from main.py
    """
    start_time = time.time()
    main()
    log.info(f"Execution Time : {(time.time()-start_time):.3f} seconds")