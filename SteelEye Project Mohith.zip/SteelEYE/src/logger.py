import logging.handlers
from datetime import datetime
import os

def logger():
    if not os.path.exists('../logs'):
        os.makedirs('../logs')
    dateToString = str(datetime.now()).replace('-','').replace(':', '').split('.')[0].replace(' ', '.' )
    logging.getLogger().setLevel(logging.INFO)

    # Add file rotating handler, with level DEBUG
    rotatingHandler = logging.handlers.RotatingFileHandler(filename='../logs/'+str(dateToString)+'.SteelEye.log')
    rotatingHandler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(name)s.%(funcName)s() %(levelname)s\t%(message)s')
    rotatingHandler.setFormatter(formatter)
    logging.getLogger().addHandler(rotatingHandler)
    return logging



