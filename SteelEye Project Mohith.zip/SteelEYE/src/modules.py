import requests
import random




def get_response(url):
    """
    :param url: input url to get data
    :return: response text
    """
    response = requests.get(url)
    return response


def extract_unique_prize_years(x):
    """
    :param x: prize column data
    :return: unique prize years
    """
    temp_year = []
    for year_dict in x:
        temp_year.append(year_dict['year'])
    return ';'.join(set(temp_year))


def extract_unique_prize_categories(x):
    """
    :param x: prize column data
    :return: unique prize categories
    """
    temp_categories = []
    for year_category in x:
        temp_categories.append(year_category['category'])
    return ';'.join(set(temp_categories))


def mapping_countries_codes(countries_codes, codes):
    """

    :param countries_codes: Countries and their respective code's dictionary
    :param codes: Code column data from customer_data dataframe
    :return: Mapped country if there are multiple, selects randomly gives on value or if None
            gives not available
    """
    try:
        countries = []
        for country, code in countries_codes.items():
            if codes == code:
                countries.append(country)
        return random.choice(countries)
    except:
        return 'Not Available'
